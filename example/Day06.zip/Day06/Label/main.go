package main

import "fmt"

func main() {
    fmt.Println("A")
    goto lb1
    fmt.Println("B")
lb1:
    fmt.Println("C")
lb2:
    for i := 1; i <= 4; i++ {
        for j := 1; j <= 4; j++ {
            if i == 3 {
                //goto lb2
                //continue lb2
                break lb2
            }
            fmt.Println(i, j)
        }
    }
}
