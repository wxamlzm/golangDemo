package math

func Add(x, y int) int {
    return x + y
}
