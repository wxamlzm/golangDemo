package math

func Sub(x, y int) int {
    return x - y
}
