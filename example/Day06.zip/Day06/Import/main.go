package main

import (
    //"Import/Math"
    //m "Import/Math"
    . "Import/Math"
    "fmt"
)

func main() {
    a, b := 123, 456
    /*
       fmt.Printf("%d+%d = %d\n", a, b, math.Add(a, b))
       fmt.Printf("%d-%d = %d\n", a, b, math.Sub(a, b))
    */
    /*
       fmt.Printf("%d+%d = %d\n", a, b, m.Add(a, b))
       fmt.Printf("%d-%d = %d\n", a, b, m.Sub(a, b))
    */
    fmt.Printf("%d+%d = %d\n", a, b, Add(a, b))
    fmt.Printf("%d-%d = %d\n", a, b, Sub(a, b))
    fmt.Printf("%d+%d = %d\n", a, b, func(x, y int) int {
        return x + y
    }(a, b))
    fmt.Printf("%d+%d = %d\n", a, b, func() int {
        return a - b
    }())
}
