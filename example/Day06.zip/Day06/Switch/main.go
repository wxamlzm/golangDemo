package main

import (
    "fmt"
    "os"
)

func main() {
    if len(os.Args) < 2 {
        fmt.Printf("Usage: %s <A|B|C>\n", os.Args[0])
        return
    }

    switch os.Args[1] {
    case "a":
        fallthrough
    case "A":
        fmt.Println("Go")

    case "b":
        fallthrough
    case "B":
        fmt.Println("C++")

    case "c":
        fallthrough
    case "C":
        fmt.Println("Python")

    default:
        fmt.Println("Invalid option")
    }
}
