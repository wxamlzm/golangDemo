package main

import "fmt"

func main() {
    a, b := 函数1(10, true, "aaa")
    fmt.Printf("%g %c\n", a, b)

    _, c := 函数1(20, true, "bbb")
    fmt.Printf("%c\n", c)

    函数2(123, 456, "789")

    d, e, f := 函数3()
    fmt.Println(d, e, f)

    var g func(int, bool, string) (float64, rune)
    g = 函数1
    h, i := g(30, true, "ccc")
    fmt.Printf("%g %c\n", h, i)

    j := [2]func(int, bool, string) (float64, rune){函数1, 函数1}
    k, l := j[0](40, true, "ddd")
    fmt.Printf("%g %c\n", k, l)
    m, n := j[1](50, true, "eee")
    fmt.Printf("%g %c\n", m, n)

    函数4(函数1)

    o, p := 函数5()(70, true, "ggg")
    fmt.Printf("%g %c\n", o, p)

    q := 函数6(123)
    fmt.Println(q, *q)
}

func 函数1(x int, y bool, z string) (float64, rune) {
    fmt.Println(x, y, z)
    return 3.1415926, 'π'
}

func 函数2(x, y int, z string) {
    fmt.Println(x, y, z)
}

func 函数3() (x, y int, z string) {
    x = 123
    y = 456
    z = "789"
    return
}

func 函数4(x func(int, bool, string) (float64, rune)) {
    a, b := x(60, true, "fff")
    fmt.Printf("%g %c\n", a, b)
}

func 函数5() func(int, bool, string) (float64, rune) {
    return 函数1
}

func 函数6(a int) *int {
    b := 456
    c := a + b
    return &c
}
