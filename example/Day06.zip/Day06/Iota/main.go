package main

import "fmt"

func main() {
    var (
        a int    = 123
        b string = "abc"
        c bool   = false
    )
    fmt.Println(a, b, c)
    /*
       const (
           SUN int = 0
           MON int = 1
           TUE int = 2
           WED int = 3
           THU int = 4
           FRI int = 5
           SAT int = 6
       )
    */
    const (
        SUN = iota
        MON = iota
        TUE
        WED, WEDNESDAY = iota, iota
        THU, THURSDAY
        FRI = iota
        SAT
    )
    fmt.Println(SUN, MON, TUE, WED, WEDNESDAY, THU, THURSDAY, FRI, SAT)

    const (
        A = iota + 1
        B
        _
        _
        C
        D
    )
    fmt.Println(A, B, C, D)
}
