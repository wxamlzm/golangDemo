package main

import (
    "fmt"
    "net"
    "net/rpc"
)

type Operands struct {
    A, B int
}

type Arithmetic struct {
}

func (arithmetic *Arithmetic) Add(ops Operands, sum *int) error {
    *sum = ops.A + ops.B
    return nil
}

func (arithmetic *Arithmetic) Sub(ops Operands, dif *int) error {
    *dif = ops.A - ops.B
    return nil
}

func main() {
    fmt.Println("注册服务")

    if err := rpc.RegisterName("arithmetic", new(Arithmetic)); err != nil {
        fmt.Println("rpc.RegisterName错误:", err)
        return
    }

    fmt.Println("启动监听")

    listener, err := net.Listen("tcp", "127.0.0.1:9000")
    if err != nil {
        fmt.Println("net.Listen错误:", err)
        return
    }

    defer func() {
        fmt.Println("结束监听")
        listener.Close()
    }()

    for {
        fmt.Println("等待连接")

        conn, err := listener.Accept()
        if err != nil {
            fmt.Println("Listener.Accept错误:", err)
            return
        }

        fmt.Println("接受连接")

        go func() {
            addr := conn.RemoteAddr().String()

            defer func() {
                fmt.Println("关闭连接:", addr)
                conn.Close()
            }()

            fmt.Println("绑定连接:", addr)
            rpc.ServeConn(conn)
        }()
    }
}
