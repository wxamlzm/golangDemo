package main

import (
    "fmt"
    "net/rpc"
)

type Operands struct {
    A, B int
}

func main() {
    fmt.Println("请求连接")

    conn, err := rpc.Dial("tcp", "127.0.0.1:9000")
    if err != nil {
        fmt.Println("rpc.Dial错误:", err)
        return
    }

    defer func() {
        fmt.Println("关闭连接")
        conn.Close()
    }()

    ops, sum, dif := Operands{123, 456}, 0, 0

    fmt.Println("远程调用")

    if err := conn.Call("arithmetic.Add", ops, &sum); err != nil {
        fmt.Println("Conn.Call错误:", err)
        return
    }

    fmt.Printf("调用返回: %d+%d = %d\n", ops.A, ops.B, sum)

    fmt.Println("远程调用")

    if err := conn.Call("arithmetic.Sub", ops, &dif); err != nil {
        fmt.Println("Conn.Call错误:", err)
        return
    }

    fmt.Printf("调用返回: %d-%d = %d\n", ops.A, ops.B, dif)
}
