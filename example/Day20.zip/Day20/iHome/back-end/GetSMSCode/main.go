package main

import (
    "GetSMSCode/handler"
    pb "GetSMSCode/proto"
    "github.com/go-micro/plugins/v4/registry/consul"

    "go-micro.dev/v4"
    "go-micro.dev/v4/logger"
)

var (
    service = "getsmscode"
    version = "latest"
)

func main() {
    // Create service
    srv := micro.NewService()
    srv.Init(
        micro.Name(service),
        micro.Version(version),
        micro.Registry(consul.NewRegistry()),
        micro.Address("127.0.0.1:9002"),
    )

    // Register handler
    if err := pb.RegisterGetSMSCodeHandler(srv.Server(), new(handler.GetSMSCode)); err != nil {
        logger.Fatal(err)
    }
    // Run service
    if err := srv.Run(); err != nil {
        logger.Fatal(err)
    }
}
