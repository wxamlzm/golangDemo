package model

import (
    "encoding/json"
    "github.com/gomodule/redigo/redis"
)

// 连接池
var pool = redis.Pool{
    MaxIdle:         20,     // 最大空闲连接数
    MaxActive:       50,     // 最大活动连接数
    MaxConnLifetime: 5 * 60, // 最大连接生命周期
    IdleTimeout:     60,     // 空闲超时
    Dial: func() (redis.Conn, error) { // 连接回调
        // 连接数据库
        return redis.Dial("tcp", "127.0.0.1:6379")
    },
}

// 从Redis数据库中加载城区列表
func LoadAreas() ([]Area, error) {
    // 从连接池中获取连接
    conn := pool.Get()

    // 关闭数据库连接
    defer conn.Close()

    // 操作数据库同时类型具体化
    jareas, err := redis.Bytes(conn.Do("get", "IHOME_AREAS"))
    if err != nil {
        return nil, err
    }

    // 将JSON字符串反序列化为城区列表
    var areas []Area
    err = json.Unmarshal(jareas, &areas)
    return areas, err
}

// 将城区列表保存到Redis数据库中
func SaveAreas(areas []Area) error {
    // 从连接池中获取连接
    conn := pool.Get()

    // 关闭数据库连接
    defer conn.Close()

    // 将城区列表序列化为JSON字符串
    jareas, err := json.Marshal(areas)
    if err != nil {
        return err
    }

    // 操作数据库
    _, err = conn.Do("set", "IHOME_AREAS", jareas)
    return err
}
