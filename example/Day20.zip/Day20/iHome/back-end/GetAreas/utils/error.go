package utils

const (
    ERROR_OK              = "0"
    ERROR_DATABASE        = "4000"
    ERROR_NO_DATA         = "4001"
    ERROR_DATA_EXIST      = "4002"
    ERROR_DATA            = "4003"
    ERROR_USER_NOT_LOGIN  = "4100"
    ERROR_USER_LOGIN      = "4101"
    ERROR_USER_LOGOUT     = "4102"
    ERROR_PARAMETERS      = "4103"
    ERROR_USER_REGISTERED = "4104"
    ERROR_USER_IDENTITY   = "4105"
    ERROR_PASSWORD        = "4106"
    ERROR_USER            = "4017"
    ERROR_SMS             = "4108"
    ERROR_MOBILE          = "4109"
    ERROR_REQUEST         = "4200"
    ERROR_IP              = "4201"
    ERROR_THIRD_PARTY     = "4300"
    ERROR_IO              = "4301"
    ERROR_INTERNAL        = "4400"
    ERROR_UNKNOWN         = "4401"
)

var errors = map[string]string{
    ERROR_OK:              "成功",
    ERROR_DATABASE:        "数据库错误",
    ERROR_NO_DATA:         "无数据",
    ERROR_DATA_EXIST:      "数据已存在",
    ERROR_DATA:            "数据错误",
    ERROR_USER_NOT_LOGIN:  "用户未登录",
    ERROR_USER_LOGIN:      "用户登录失败",
    ERROR_USER_LOGOUT:     "用户退出失败",
    ERROR_PARAMETERS:      "参数错误",
    ERROR_USER_REGISTERED: "用户已注册",
    ERROR_USER_IDENTITY:   "用户身份错误",
    ERROR_PASSWORD:        "密码错误",
    ERROR_USER:            "用户不存在或未激活",
    ERROR_SMS:             "短信失败",
    ERROR_MOBILE:          "手机号错误",
    ERROR_REQUEST:         "非法请求或请求次数受限",
    ERROR_IP:              "IP受限",
    ERROR_THIRD_PARTY:     "第三方系统错误",
    ERROR_IO:              "读写文件失败",
    ERROR_INTERNAL:        "内部错误",
    ERROR_UNKNOWN:         "未知错误",
}

func StrError(code string) string {
    desc, ok := errors[code]

    if ok {
        return desc
    }

    return errors[ERROR_UNKNOWN]
}
