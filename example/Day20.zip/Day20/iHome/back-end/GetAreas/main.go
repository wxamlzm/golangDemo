package main

import (
	"GetAreas/handler"
	"GetAreas/model"
	pb "GetAreas/proto"
	"github.com/go-micro/plugins/v4/registry/consul"

	"go-micro.dev/v4"
	"go-micro.dev/v4/logger"
)

var (
	service = "getareas"
	version = "latest"
)

func main() {
	// 初始化数据库
	if err := model.InitDB(); err != nil {
		logger.Fatal(err)
	}

	// Create service
	srv := micro.NewService()
	srv.Init(
		micro.Name(service),
		micro.Version(version),
		micro.Registry(consul.NewRegistry()),
		micro.Address("127.0.0.1:9004"),
	)

	// Register handler
	if err := pb.RegisterGetAreasHandler(srv.Server(), new(handler.GetAreas)); err != nil {
		logger.Fatal(err)
	}
	// Run service
	if err := srv.Run(); err != nil {
		logger.Fatal(err)
	}
}
