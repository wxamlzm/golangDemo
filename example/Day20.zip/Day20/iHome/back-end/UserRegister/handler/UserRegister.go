package handler

import (
    "UserRegister/model"
    "UserRegister/utils"
    "context"
    "io"
    "time"

    "go-micro.dev/v4/logger"

    pb "UserRegister/proto"
)

type UserRegister struct{}

func (e *UserRegister) Call(ctx context.Context, req *pb.CallRequest, rsp *pb.CallResponse) error {
    logger.Infof("Received UserRegister.Call request: %v", req)

    // 从Redis数据库中读取短信验证码
    code, err := model.ReadSMSCode(req.Mobile)
    if err != nil {
        logger.Error(err)
        rsp.Errno = utils.ERROR_DATABASE
        rsp.Errmsg = utils.StrError(rsp.Errno)
        return nil
    }

    // 校验短信验证码
    if req.Code != code {
        logger.Error("短信验证码校验失败")
        rsp.Errno = utils.ERROR_DATA
        rsp.Errmsg = utils.StrError(rsp.Errno)
        return nil
    }

    // 将用户信息保存到MySQL数据库中
    err = model.SaveUser(req.Mobile, req.Passwd)
    if err != nil {
        logger.Error(err)
        rsp.Errno = utils.ERROR_DATABASE
        rsp.Errmsg = utils.StrError(rsp.Errno)
        return nil
    }

    rsp.Errno = utils.ERROR_OK
    rsp.Errmsg = utils.StrError(rsp.Errno)
    return nil
}

func (e *UserRegister) ClientStream(ctx context.Context, stream pb.UserRegister_ClientStreamStream) error {
    var count int64
    for {
        req, err := stream.Recv()
        if err == io.EOF {
            logger.Infof("Got %v pings total", count)
            return stream.SendMsg(&pb.ClientStreamResponse{Count: count})
        }
        if err != nil {
            return err
        }
        logger.Infof("Got ping %v", req.Stroke)
        count++
    }
}

func (e *UserRegister) ServerStream(ctx context.Context, req *pb.ServerStreamRequest, stream pb.UserRegister_ServerStreamStream) error {
    logger.Infof("Received UserRegister.ServerStream request: %v", req)
    for i := 0; i < int(req.Count); i++ {
        logger.Infof("Sending %d", i)
        if err := stream.Send(&pb.ServerStreamResponse{
            Count: int64(i),
        }); err != nil {
            return err
        }
        time.Sleep(time.Millisecond * 250)
    }
    return nil
}

func (e *UserRegister) BidiStream(ctx context.Context, stream pb.UserRegister_BidiStreamStream) error {
    for {
        req, err := stream.Recv()
        if err == io.EOF {
            return nil
        }
        if err != nil {
            return err
        }
        logger.Infof("Got ping %v", req.Stroke)
        if err := stream.Send(&pb.BidiStreamResponse{Stroke: req.Stroke}); err != nil {
            return err
        }
    }
}
