package main

import (
    "fmt"
    "github.com/gin-contrib/sessions"
    "github.com/gin-contrib/sessions/redis"
    "github.com/gin-gonic/gin"
)

func main() {
    // 初始化路由
    router := gin.Default()

    // 创建Session容器
    store, err := redis.NewStore(
        10, "tcp", "localhost:6379", "", []byte("secret"))
    if err != nil {
        fmt.Println(err)
        return
    }

    // 为容器中的Session设置Cookie选项
    store.Options(sessions.Options{
        Path:     "",
        Domain:   "",
        MaxAge:   10, // 最后一次请求后10即销毁
        Secure:   true,
        HttpOnly: true,
    })

    // 为容器中的Session设置Cookie键
    router.Use(sessions.Sessions("mysession", store));

    // 路由匹配
    router.GET("/", func(contex *gin.Context) {
        counter := 0

        // 获取Session
        session := sessions.Default(contex)
        // 获取Session中指定键的值
        if icounter := session.Get("counter"); icounter != nil {
            counter = icounter.(int) + 1
        }
        // 设置Session中指定键的值
        session.Set("counter", counter)
        // 保存Session
        session.Save()

        contex.Writer.WriteString(fmt.Sprintf("%d", counter))
    })

    // 运行
    router.Run(":8080")
}
