package main

import "github.com/gin-gonic/gin"

func main() {
    // 初始化路由
    router := gin.Default()

    // 路由匹配
    router.GET("/", func(contex *gin.Context) {
        // 设置Cookie
        contex.SetCookie("username", "zhangfei", 3600, "", "", true, true)
        contex.Writer.WriteString("Set Cookie")
    })

    // 运行
    router.Run(":8080")
}
