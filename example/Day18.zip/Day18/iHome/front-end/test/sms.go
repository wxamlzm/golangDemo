package main

import (
    "fmt"
    "github.com/aliyun/alibaba-cloud-sdk-go/sdk"
    "github.com/aliyun/alibaba-cloud-sdk-go/sdk/auth/credentials"
    "github.com/aliyun/alibaba-cloud-sdk-go/services/dysmsapi"
)

func main() {
    config := sdk.NewConfig()
    credential := credentials.NewAccessKeyCredential(
        "LTAI5tFHmjLeU9LuKGv1WBDy", "SuYPV5PaRPaE1eBjrjYSTiQMk8Sb0Y")
    client, err := dysmsapi.NewClientWithOptions(
        "cn-hangzhou", config, credential)
    if err != nil {
        fmt.Println("dysmsapi.NewClientWithOptions错误:", err)
        return
    }

    request := dysmsapi.CreateSendSmsRequest()
    request.Scheme = "https"
    request.SignName = "阿里云短信测试"
    request.TemplateCode = "SMS_154950909"
    request.PhoneNumbers = "13552654195"
    request.TemplateParam = "{\"code\": \"740523\"}"

    response, err := client.SendSms(request)
    if err != nil {
        fmt.Println("Client.SendSms错误:", err)
        return
    }

    fmt.Println(response.Code, response.Message)
}
