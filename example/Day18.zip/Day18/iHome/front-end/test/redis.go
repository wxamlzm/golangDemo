package main

import (
    "fmt"
    "github.com/gomodule/redigo/redis"
)

func main() {
    // 连接数据库
    conn, err := redis.Dial("tcp", "127.0.0.1:6379")
    if err != nil {
        fmt.Println("Redis错误:", err)
        return
    }

    // 关闭数据库连接
    defer conn.Close()

    // 操作数据库
    reply, err := conn.Do("set", "name", "zhangfei")
    if err != nil {
        fmt.Println("Redis错误:", err)
        return
    }

    // 类型具体化
    result, err := redis.String(reply, err)
    if err != nil {
        fmt.Println("Redis错误:", err)
        return
    }
    fmt.Println(result)

    // 操作数据库同时类型具体化
    name, err := redis.String(conn.Do("get", "name"))
    if err != nil {
        fmt.Println("Redis错误:", err)
        return
    }
    fmt.Println(name)

    // 简化书写
    if _, err := conn.Do("set", "age", 25); err != nil {
        fmt.Println("Redis错误:", err)
        return
    }

    // 操作数据库同时类型具体化
    age, err := redis.Int(conn.Do("get", "age"))
    if err != nil {
        fmt.Println("Redis错误:", err)
        return
    }
    fmt.Println(age)

    // 列出所有的键
    keys, err := redis.Strings(conn.Do("keys", "*"))
    if err != nil {
        fmt.Println("Redis错误:", err)
        return
    }
    fmt.Println(keys)

    // 清空数据库
    if _, err := conn.Do("flushall"); err != nil {
        fmt.Println("Redis错误:", err)
        return
    }

    // 列出所有的键
    keys, err = redis.Strings(conn.Do("keys", "*"))
    if err != nil {
        fmt.Println("Redis错误:", err)
        return
    }
    fmt.Println(keys)
}
