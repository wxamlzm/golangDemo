package controller

import (
    "context"
    "encoding/json"
    "fmt"
    "github.com/afocus/captcha"
    "github.com/gin-gonic/gin"
    "github.com/go-micro/plugins/v4/registry/consul"
    "go-micro.dev/v4"
    pbGetImageCode "iHome/front-end/proto/GetImageCode"
    pbGetSMSCode "iHome/front-end/proto/GetSMSCode"
    "iHome/front-end/utils"
    "image/png"
    "net/http"
)

// 获取Session
func GetSession(ctx *gin.Context) {
    rsp := make(map[string]string)
    rsp["errno"] = utils.ERROR_USER_NOT_LOGIN
    rsp["errmsg"] = utils.StrError(rsp["errno"])

    ctx.JSON(http.StatusOK, rsp)
}

// 获取图片验证码
func GetImageCode(ctx *gin.Context) {
    // 获取图片验证码的UUID
    uuid := ctx.Param("uuid")
    fmt.Println(uuid)

    // 调用微服务
    srv := micro.NewService(micro.Registry(consul.NewRegistry()))
    srv.Init()
    c := pbGetImageCode.NewGetImageCodeService("getimagecode", srv.Client())
    rsp, err := c.Call(context.Background(), &pbGetImageCode.CallRequest{
        Uuid: uuid,
    })
    if err != nil {
        fmt.Println(err)
        return
    }

    // 反序列化验证码图片
    var img captcha.Image
    json.Unmarshal(rsp.Img, &img)
    png.Encode(ctx.Writer, img)
}

// 获取短信验证码
func GetSMSCode(ctx *gin.Context) {
    // 获取手机号
    mobile := ctx.Param("mobile")
    // 获取图片验证码字符串
    text := ctx.Query("text")
    // 获取图片验证码UUID
    uuid := ctx.Query("id")

    // 调用微服务
    srv := micro.NewService(micro.Registry(consul.NewRegistry()))
    srv.Init()
    c := pbGetSMSCode.NewGetSMSCodeService("getsmscode", srv.Client())
    rsp, err := c.Call(context.Background(), &pbGetSMSCode.CallRequest{
        Mobile: mobile,
        Text:   text,
        Uuid:   uuid,
    })
    if err != nil {
        fmt.Println(err)
        return
    }

    ctx.JSON(http.StatusOK, rsp)
}

// 用户注册
func UserRegister(ctx *gin.Context) {
    // 获取手机号、密码和短信验证码
    req := struct {
        Mobile string `json:"mobile"`
        Passwd string `json:"password"`
        Code   string `json:"sms_code"`
    }{}
    ctx.Bind(&req)

    fmt.Println(req.Mobile, req.Passwd, req.Code)
}
