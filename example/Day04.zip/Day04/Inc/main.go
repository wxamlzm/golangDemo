package main

import "fmt"

func main() {
    a := 10
    fmt.Println(a)
    a++
    fmt.Println(a)
    a--
    fmt.Println(a)
    //++a
    //--a
    //fmt.Println(a++)
    //b := a--
}
