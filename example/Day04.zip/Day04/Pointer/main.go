package main

import "fmt"

func main() {
    a := 10
    b := &a
    fmt.Println(b, *b)
    *b = 20
    fmt.Println(a)
    var c **int = &b
    fmt.Println(c, *c, **c)

    d := &a
    fmt.Println(b == d, b != d)
    //fmt.Println(b > d, b < d, b-d)
    //b = b + 1
    //b++

    e := new(string)
    *e = "beijing"
    fmt.Println(e, *e)

    h := foo()
    fmt.Println(h, *h)

    h = nil
    fmt.Println(h, h == nil)
}

func foo() *int {
    f := 30
    g := &f
    return g
}
