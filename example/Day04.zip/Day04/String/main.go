package main

import "fmt"

func main() {
    a := "123456789"
    fmt.Println(a)
    b := `123456789`
    fmt.Println(b)

    c := "123\n456\n789"
    fmt.Println(c)
    d := `123\n456\n789`
    fmt.Println(d)
    e := `123
456
789`
    fmt.Println(e)

    f := "123\"456\"789"
    fmt.Println(f)
    g := "123`456`789"
    fmt.Println(g)
    h := `123"456"789`
    fmt.Println(h)
    //i := `123`456`789`

    fmt.Println(len(c), len(d), len(e))
    j := "123四五六789"
    fmt.Println(j, len(j))
    for i := 0; i < len(j); i++ {
        fmt.Printf("%x ", j[i])
    }
    fmt.Println()

    k, l := "123", `456`
    m := k + l + "789"
    fmt.Println(m)

    fmt.Println("abc" > "aB")
    fmt.Println("abc" == "abc")
    fmt.Println("abc" != "ABC")

    n := "google"
    fmt.Println(n)
    //n[0] = 'G'
    n = "Google"
    fmt.Println(n)
    const o = "google"
    fmt.Println(o)
    //o = "Google"
}
