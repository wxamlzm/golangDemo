package main

import "fmt"

func main() {
    var a [5]int
    a[0], a[1], a[2] = 1, 2, 3
    fmt.Println(a)
    var b [5]int = [5]int{1, 2, 3}
    fmt.Println(b)
    var c = [5]int{1, 2, 3}
    fmt.Println(c)
    d := [5]int{1, 2, 3}
    fmt.Println(d)

    for i := 0; i < len(a); i++ {
        fmt.Printf("a[%d]: %d\n", i, a[i])
    }
    for i := 0; i < len(a); i++ {
        a[i] *= 10
    }
    fmt.Println(a)
    for key, value := range b {
        fmt.Printf("b[%d]: %d\n", key, value)
    }
}
