package main

import (
    "fmt"
    "os"
    "time"
)

func main() {
    fmt.Println("进入main函数")
    go foo()
    time.Sleep(1 * time.Second)
    fmt.Println("main函数返回")
}

func foo() {
    fmt.Println("进入foo函数")
    bar()
    fmt.Println("foo函数提前返回")
    return
    fmt.Println("foo函数返回")
}

func bar() {
    fmt.Println("进入bar函数")
    //fmt.Println("bar函数提前返回")
    //return
    //runtime.Goexit()
    os.Exit(0)
    fmt.Println("bar函数返回")
}
