package math

type Calculator struct {
    x int
    y int
}

func (c *Calculator) Set(x, y int) {
    c.x = x
    c.y = y
}

func (c Calculator) Get() (int, int) {
    return c.x, c.y
}

func (c Calculator) Add() int {
    return c.x + c.y
}

func (c Calculator) Sub() int {
    return c.x - c.y
}
