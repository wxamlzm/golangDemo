package main

import (
    math "Scope/Math"
    "fmt"
)

func main() {
    c := math.Calculator{}
    c.Set(123, 456)
    x, y := c.Get()
    fmt.Printf("%d+%d = %d\n", x, y, c.Add())
    fmt.Printf("%d-%d = %d\n", x, y, c.Sub())
}
