package main

import (
    "fmt"
    "time"
)

func main() {
    go routine('-', 100)
    routine('+', 500)
}

func routine(c rune, d time.Duration) {
    for {
        fmt.Printf("%c", c)
        time.Sleep(d * time.Millisecond)
    }
}
