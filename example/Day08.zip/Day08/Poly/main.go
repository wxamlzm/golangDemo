package main

import "fmt"

type Shape interface {
    Draw()
}

type Rectangle struct {
    X, Y, W, H int
}

func (r Rectangle) Draw() {
    fmt.Printf("在(%d,%d)处画一个宽%d高%d的矩形。\n", r.X, r.Y, r.W, r.H)
}

type Circle struct {
    X, Y, R int
}

func (c *Circle) Draw() {
    fmt.Printf("在(%d,%d)处画一个半径为%d的圆形。\n", c.X, c.Y, c.R)
}

func main() {
    r := Rectangle{
        X: 100,
        Y: 200,
        W: 300,
        H: 400,
    }
    c := Circle{
        X: 500,
        Y: 600,
        R: 700,
    }

    draw(r)
    draw(&c)
}

func draw(shape Shape) {
    shape.Draw()
}
