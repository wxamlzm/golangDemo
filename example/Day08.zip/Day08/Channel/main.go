package main

import (
    "fmt"
    "time"
)

func main() {
    ch := make(chan int)

    go func() {
        for {
            fmt.Printf("%d ", <-ch)
        }
    }()

    for i := 0; i < 10; i++ {
        ch <- i
    }

    time.Sleep(time.Second)
}
