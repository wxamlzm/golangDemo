package main

import "fmt"

func main() {
    a, b, c, d := 123, "abc", false, []float64{1.23, 4.56, 7.89}
    fmt.Printf("%T %v\n", a, a)
    fmt.Printf("%T %v\n", b, b)
    fmt.Printf("%T %v\n", c, c)
    fmt.Printf("%T %v\n", d, d)
    var e, f, g, h interface{} = a, b, c, d
    fmt.Printf("%T %v\n", e, e)
    fmt.Printf("%T %v\n", f, f)
    fmt.Printf("%T %v\n", g, g)
    fmt.Printf("%T %v\n", h, h)
    e = b
    fmt.Printf("%T %v\n", e, e)

    i := []interface{}{a, b, c, d}
    for _, j := range i {
        fmt.Printf("%T %v\n", j, j)
    }

    foo(a)
    foo(b)
    foo(c)
    foo(d)
}

func foo(a interface{}) {
    fmt.Printf("%T %v\n", a, a)
    switch a.(type) {
    case int:
        fmt.Println("整数", a)
    case string:
        fmt.Println("字符串", a)
    case bool:
        fmt.Println("布尔值", a)
    case []float64:
        fmt.Println("双精度浮点数切片", a)
    }
}
