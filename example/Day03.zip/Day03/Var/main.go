package main

import "fmt"

func main() {
    var a string
    a = "beijing"
    fmt.Println(a)

    var b int = 10
    fmt.Println(b)

    var c = 3.14
    fmt.Println(c)
    fmt.Printf("%T\n", c)

    d := true
    fmt.Printf("%v %T\n", d, d)

    e, f := "shanghai", 20
    fmt.Println(e, f)

    g, h := 30, 40
    fmt.Println(g, h)
    g, h = h, g
    fmt.Println(g, h)
}
