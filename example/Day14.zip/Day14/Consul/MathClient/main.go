package main

import (
    "context"
    "fmt"
    "gRPC/pb"
    "github.com/hashicorp/consul/api"
    "google.golang.org/grpc"
    "google.golang.org/grpc/credentials/insecure"
    "strconv"
)

func main() {
    fmt.Println("从Consul中获取健康服务")

    // 获取Consul默认配置
    config := api.DefaultConfig()
    // 创建Consul客户机
    client, err := api.NewClient(config)
    if err != nil {
        fmt.Println("api.NewClient错误:", err)
        return
    }
    // 从Consul获取健康服务
    services, _, err := client.Health().Service(
        "arithmetic", "math", true, nil)
    if err != nil {
        fmt.Println("Health.Service错误:", err)
        return
    }

    fmt.Println("请求连接")

    service := services[0].Service
    conn, err := grpc.Dial(service.Address+":"+strconv.Itoa(service.Port),
        grpc.WithTransportCredentials(insecure.NewCredentials()))
    if err != nil {
        fmt.Println("grpc.Dial错误:", err)
        return
    }

    defer func() {
        fmt.Println("关闭连接")
        conn.Close()
    }()

    arithmetic := pb.NewArithmeticClient(conn)

    var ops pb.Operands
    ops.A, ops.B = 123, 456

    fmt.Println("远程调用")

    if res, err := arithmetic.Add(context.TODO(), &ops); err != nil {
        fmt.Println("ArithmeticClient.Add错误:", err)
        return
    } else {
        fmt.Printf("调用返回: %d+%d=%d\n", ops.A, ops.B, res.C)
    }

    fmt.Println("远程调用")

    if res, err := arithmetic.Sub(context.TODO(), &ops); err != nil {
        fmt.Println("ArithmeticClient.Add错误:", err)
        return
    } else {
        fmt.Printf("调用返回: %d-%d=%d\n", ops.A, ops.B, res.C)
    }
}
