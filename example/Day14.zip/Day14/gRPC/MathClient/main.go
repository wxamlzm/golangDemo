package main

import (
    "context"
    "fmt"
    "gRPC/pb"
    "google.golang.org/grpc"
    "google.golang.org/grpc/credentials/insecure"
)

func main() {
    fmt.Println("请求连接")

    conn, err := grpc.Dial("127.0.0.1:9000",
        grpc.WithTransportCredentials(insecure.NewCredentials()))
    if err != nil {
        fmt.Println("grpc.Dial错误:", err)
        return
    }

    defer func() {
        fmt.Println("关闭连接")
        conn.Close()
    }()

    arithmetic := pb.NewArithmeticClient(conn)

    var ops pb.Operands
    ops.A, ops.B = 123, 456

    fmt.Println("远程调用")

    if res, err := arithmetic.Add(context.TODO(), &ops); err != nil {
        fmt.Println("ArithmeticClient.Add错误:", err)
        return
    } else {
        fmt.Printf("调用返回: %d+%d=%d\n", ops.A, ops.B, res.C)
    }

    fmt.Println("远程调用")

    if res, err := arithmetic.Sub(context.TODO(), &ops); err != nil {
        fmt.Println("ArithmeticClient.Add错误:", err)
        return
    } else {
        fmt.Printf("调用返回: %d-%d=%d\n", ops.A, ops.B, res.C)
    }
}
