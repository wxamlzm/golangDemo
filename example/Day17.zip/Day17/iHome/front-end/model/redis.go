package model

import "github.com/gomodule/redigo/redis"

// 从Redis数据库中读取图片验证码字符串
func ReadImageCode(uuid string) (string, error) {
    // 连接数据库
    conn, err := redis.Dial("tcp", "127.0.0.1:6379")
    if err != nil {
        return "", err
    }

    // 关闭数据库连接
    defer conn.Close()

    // 操作数据库同时类型具体
    return redis.String(conn.Do("get", uuid))
}
