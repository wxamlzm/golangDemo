package controller

import (
    "context"
    "encoding/json"
    "fmt"
    "github.com/afocus/captcha"
    "github.com/aliyun/alibaba-cloud-sdk-go/sdk"
    "github.com/aliyun/alibaba-cloud-sdk-go/sdk/auth/credentials"
    "github.com/aliyun/alibaba-cloud-sdk-go/services/dysmsapi"
    "github.com/gin-gonic/gin"
    "github.com/go-micro/plugins/v4/registry/consul"
    "go-micro.dev/v4"
    "iHome/front-end/model"
    pbGetImageCode "iHome/front-end/proto/GetImageCode"
    "iHome/front-end/utils"
    "image/png"
    "math/rand"
    "net/http"
    "time"
)

// 获取Session
func GetSession(ctx *gin.Context) {
    rsp := make(map[string]string)
    rsp["errno"] = utils.ERROR_USER_NOT_LOGIN
    rsp["errmsg"] = utils.StrError(rsp["errno"])

    ctx.JSON(http.StatusOK, rsp)
}

// 获取图片验证码
func GetImageCode(ctx *gin.Context) {
    // 获取图片验证码的UUID
    uuid := ctx.Param("uuid")
    fmt.Println(uuid)

    // 调用微服务
    srv := micro.NewService(micro.Registry(consul.NewRegistry()))
    srv.Init()
    c := pbGetImageCode.NewGetImageCodeService("getimagecode", srv.Client())
    rsp, err := c.Call(context.Background(), &pbGetImageCode.CallRequest{
        Uuid: uuid,
    })
    if err != nil {
        fmt.Println(err)
        return
    }

    // 反序列化验证码图片
    var img captcha.Image
    json.Unmarshal(rsp.Img, &img)
    png.Encode(ctx.Writer, img)
}

// 获取短信验证码
func GetSMSCode(ctx *gin.Context) {
    // 获取手机号
    mobile := ctx.Param("mobile")
    // 获取图片验证码字符串
    text := ctx.Query("text")
    // 获取图片验证码UUID
    uuid := ctx.Query("id")

    rsp := make(map[string]string)

    // 从Redis数据库中读取图片验证码字符串
    str, err := model.ReadImageCode(uuid)
    if err != nil {
        fmt.Println(err)
        rsp["errno"] = utils.ERROR_DATABASE
        rsp["errmsg"] = utils.StrError(rsp["errno"])
        ctx.JSON(http.StatusOK, rsp)
        return
    }

    // 校验图片验证码
    if text != str {
        fmt.Println("图片验证码校验失败")
        rsp["errno"] = utils.ERROR_DATA
        rsp["errmsg"] = utils.StrError(rsp["errno"])
        ctx.JSON(http.StatusOK, rsp)
        return
    }

    // 发送短信验证码
    config := sdk.NewConfig()
    credential := credentials.NewAccessKeyCredential(
        "LTAI5tFHmjLeU9LuKGv1WBDy", "SuYPV5PaRPaE1eBjrjYSTiQMk8Sb0Y")
    client, err := dysmsapi.NewClientWithOptions(
        "cn-hangzhou", config, credential)
    if err != nil {
        fmt.Println(err)
        rsp["errno"] = utils.ERROR_SMS
        rsp["errmsg"] = utils.StrError(rsp["errno"])
        ctx.JSON(http.StatusOK, rsp)
        return
    }
    request := dysmsapi.CreateSendSmsRequest()
    request.Scheme = "https"
    request.SignName = "阿里云短信测试"
    request.TemplateCode = "SMS_154950909"
    request.PhoneNumbers = mobile
    rand.Seed(time.Now().UnixNano())
    code := fmt.Sprintf("%06d", rand.Int31n(999999))
    request.TemplateParam = "{\"code\": \"" + code + "\"}"
    response, err := client.SendSms(request)
    if err != nil {
        fmt.Println(err)
        rsp["errno"] = utils.ERROR_SMS
        rsp["errmsg"] = utils.StrError(rsp["errno"])
        ctx.JSON(http.StatusOK, rsp)
        return
    }
    if response.Code != "OK" {
        fmt.Println(response.Message)
        rsp["errno"] = utils.ERROR_SMS
        rsp["errmsg"] = utils.StrError(rsp["errno"])
        ctx.JSON(http.StatusOK, rsp)
        return
    }

    rsp["errno"] = utils.ERROR_OK
    rsp["errmsg"] = utils.StrError(rsp["errno"])
    ctx.JSON(http.StatusOK, rsp)
}
