package main

import (
    "github.com/afocus/captcha"
    "image/color"
    "image/png"
    "net/http"
)

func main() {
    http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
        cap := captcha.New()                              // 创建图片验证码生成器
        cap.SetFont("../resources/comic.ttf")             // 设置字体
        cap.SetSize(128, 64)                              // 设置图片大小
        cap.SetDisturbance(captcha.MEDIUM)                // 设置干扰强度
        cap.SetFrontColor(color.RGBA{255, 255, 255, 255}) // 设置前景色
        cap.SetBkgColor(
            color.RGBA{255, 0, 0, 255},
            color.RGBA{0, 255, 0, 255},
            color.RGBA{0, 0, 255, 255}) // 设置背景色
        img, str := cap.Create(4, captcha.ALL)

        png.Encode(w, img)

        println(str)
    })

    http.ListenAndServe(":8888", nil)
}
