package model

import (
    "github.com/gomodule/redigo/redis"
)

// 将图片验证码的UUID和验证码字符串保存到Redis数据库中
func SaveImageCode(uuid, str string) error {
    // 连接数据库
    conn, err := redis.Dial("tcp", "127.0.0.1:6379")
    if err != nil {
        return err
    }

    // 关闭数据库连接
    defer conn.Close()

    // 操作数据库
    _, err = conn.Do("setex", uuid, 60*5, str)
    return err
}
