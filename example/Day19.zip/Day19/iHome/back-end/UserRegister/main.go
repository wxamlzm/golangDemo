package main

import (
    "UserRegister/handler"
    "UserRegister/model"
    pb "UserRegister/proto"
    "github.com/go-micro/plugins/v4/registry/consul"
    "go-micro.dev/v4"
    "go-micro.dev/v4/logger"
)

var (
    service = "userregister"
    version = "latest"
)

func main() {
    // 初始化数据库
    if err := model.InitDB(); err != nil {
        logger.Fatal(err)
    }

    // Create service
    srv := micro.NewService()
    srv.Init(
        micro.Name(service),
        micro.Version(version),
        micro.Registry(consul.NewRegistry()),
        micro.Address("127.0.0.1:9003"),
    )

    // Register handler
    if err := pb.RegisterUserRegisterHandler(srv.Server(), new(handler.UserRegister)); err != nil {
        logger.Fatal(err)
    }
    // Run service
    if err := srv.Run(); err != nil {
        logger.Fatal(err)
    }
}
