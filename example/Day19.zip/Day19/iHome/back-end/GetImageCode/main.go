package main

import (
	"GetImageCode/handler"
	pb "GetImageCode/proto"

	"go-micro.dev/v4"
	"go-micro.dev/v4/logger"

	"github.com/go-micro/plugins/v4/registry/consul"
)

var (
	service = "getimagecode"
	version = "latest"
)

func main() {
	// Create service
	srv := micro.NewService()
	srv.Init(
		micro.Name(service),
		micro.Version(version),
		micro.Registry(consul.NewRegistry()),
		micro.Address("127.0.0.1:9001"),
	)

	// Register handler
	if err := pb.RegisterGetImageCodeHandler(srv.Server(), new(handler.GetImageCode)); err != nil {
		logger.Fatal(err)
	}
	// Run service
	if err := srv.Run(); err != nil {
		logger.Fatal(err)
	}
}
