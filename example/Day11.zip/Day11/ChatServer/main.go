package main

import (
    "fmt"
    "net"
    "strings"
    "sync"
    "time"
)

type User struct {
    name    string
    addr    string
    conn    net.Conn
    channel chan string
}

var users = make(map[string]*User)

var lock sync.RWMutex

var common = make(chan string, 10)

func main() {
    fmt.Println("主线程> 启动监听")

    listener, err := net.Listen("tcp", ":8888")
    if err != nil {
        fmt.Println("主线程> net.Listen错误:", err)
        return
    }

    go broadcast()

    for {
        fmt.Println("主线程> 等待连接")

        conn, err := listener.Accept()
        if err != nil {
            fmt.Println("主线程> Listener.Accept错误:", err)
            return
        }

        fmt.Println("主线程> 接受连接")

        go receiver(conn)
    }
}

func broadcast() {
    for {
        message := <-common
        fmt.Println("广播线程>", message)

        lock.Lock()
        for _, user := range users {
            user.channel <- message
        }
        lock.Unlock()
    }
}

func receiver(conn net.Conn) {
    fmt.Println("接收线程> 开始接收")

    addr := conn.RemoteAddr().String()

    user := User{
        name:    addr,
        addr:    addr,
        conn:    conn,
        channel: make(chan string, 10),
    }

    lock.Lock()
    users[addr] = &user
    lock.Unlock()

    common <- fmt.Sprintf("%s@%s: 进入聊天室", user.name, user.addr)

    go sender(user)

    for {
        fmt.Println("接收线程> 接收消息")

        read := make(chan bool)
        go timeout(user, read)

        buf := make([]byte, 1024)
        num, err := conn.Read(buf)
        if err != nil {
            fmt.Println("接收线程> Conn.Read错误:", err)
            break
        }

        read <- true

        fmt.Printf("接收线程> 成功接收: %d字节\n", num)
        message := string(buf[:num])
        fmt.Println("接收线程> 消息内容:", message)

        if doMessage(user, message) == false {
            break
        }
    }

    lock.Lock()
    delete(users, addr)
    lock.Unlock()
    close(user.channel)
    conn.Close()

    common <- fmt.Sprintf("%s@%s: 离开聊天室", user.name, user.addr)

    fmt.Println("接收线程> 结束接收")
}

func sender(user User) {
    fmt.Println("发送线程> 开始发送")

    for {
        message, ok := <-user.channel
        if !ok {
            fmt.Println("发送线程> 通道关闭")
            break
        }
        fmt.Println("发送线程> 消息内容:", message)

        fmt.Println("发送线程> 发送消息")

        num, err := user.conn.Write([]byte(message))
        if err != nil {
            fmt.Println("发送线程> Conn.Write错误:", err)
        } else
        {
            fmt.Printf("发送线程> 成功发送: %d字节\n", num)
        }
    }

    fmt.Println("发送线程> 结束发送")
}

func timeout(user User, read chan bool) {
    select {
    case <-read:
        return

    case <-time.After(time.Minute):
        common <- fmt.Sprintf("%s@%s: 赶走潜水员", user.name, user.addr)
        user.conn.Close()
    }
}

func doMessage(user User, message string) bool {
    if message[0] == '!' {
        return doCommand(user, message)
    }

    return doChat(user, message)
}

func doCommand(requester User, command string) bool {
    argv := strings.Fields(command)
    argc := len(argv)

    switch argv[0] {
    case "!rename":
        if argc == 2 {
            return doRename(requester, argv[1])
        }

    case "!who":
        if argc == 1 {
            return doWho(requester)
        }

    case "!quit":
        if argc == 1 {
            return doQuit(requester)
        }
    }

    message := "无效命令: "
    for _, arg := range argv {
        message += fmt.Sprintf("%s ", arg)
    }
    requester.channel <- message

    return true
}

func doChat(user User, message string) bool {
    common <- fmt.Sprintf("%s@%s: %s", user.name, user.addr, message)
    return true
}

func doRename(requester User, newName string) bool {
    fmt.Printf("接收线程> 处理%s@%s的更名命令\n",
        requester.name, requester.addr)

    lock.Lock()
    oldName := users[requester.addr].name
    users[requester.addr].name = newName
    lock.Unlock()
    requester.channel <- fmt.Sprintf("[%s]->[%s]", oldName, newName)

    return true
}

func doWho(requester User) bool {
    fmt.Printf("接收线程> 处理%s@%s的查询命令\n",
        requester.name, requester.addr)

    message := ""
    lock.Lock()
    for _, user := range users {
        message += fmt.Sprintf("[%s]", user.name)
    }
    lock.Unlock()
    requester.channel <- message

    return true
}

func doQuit(requester User) bool {
    fmt.Printf("接收线程> 处理%s@%s的退出命令\n",
        requester.name, requester.addr)

    return false
}
