package main

import (
    "encoding/json"
    "fmt"
)

type Student struct {
    Name        string              `json:"name"`
    Gender      string              `json:"gender"`
    Age         int                 `json:"age"`
    Courses     []string            `json:"courses"`
    Scores      []float32           `json:"成绩"`
    Electricals map[string]string   `json:"家电"`
    Friends     []map[string]string `json:"friends"`
}

func main() {
    stu1 := Student{
        Name:        "张飞",
        Gender:      "男",
        Age:         25,
        Courses:     []string{"语文", "数学", "英语", "物理", "化学"},
        Scores:      []float32{80, 85, 70, 90, 75},
        Electricals: make(map[string]string, 3),
        Friends: []map[string]string{
            make(map[string]string, 2),
            make(map[string]string, 2),
            make(map[string]string, 2),
        },
    }
    stu1.Electricals["洗衣机"] = "海尔"
    stu1.Electricals["电视"] = "三星"
    stu1.Electricals["电冰箱"] = "西门子"
    stu1.Friends[0]["address"] = "北京"
    stu1.Friends[0]["name"] = "Tina"
    stu1.Friends[1]["address"] = "香港"
    stu1.Friends[1]["name"] = "Andy"
    stu1.Friends[2]["address"] = "台湾"
    stu1.Friends[2]["name"] = "Abby"
    jstr, err := json.Marshal(stu1)
    if err != nil {
        fmt.Println("json.Marchal错误")
        return
    }
    fmt.Println(string(jstr))

    stu2 := Student{}
    if err = json.Unmarshal(jstr, &stu2); err != nil {
        fmt.Println("json.Unmarchal错误")
        return
    }
    fmt.Printf("%+v\n", stu2)
}
