package main

import (
    "bufio"
    "fmt"
    "io"
    "net"
    "os"
    "strings"
)

func main() {
    conn, err := net.Dial("tcp", "127.0.0.1:8888")
    if err != nil {
        fmt.Println("net.Dial错误:", err)
        return
    }

    go func() {
        message := make([]byte, 1024)
        num, err := conn.Read(message)
        if err != nil {
            if err != io.EOF {
                fmt.Println("Conn.Read错误:", err)
            }
            os.Exit(0)
        }

        fmt.Println(">", string(message[:num]))
    }()

    for {
        message := ""
        reader := bufio.NewReader(os.Stdin)
        message, _ = reader.ReadString('\n')
        message = strings.TrimSpace(message)

        _, err := conn.Write([]byte(message))
        if err != nil {
            fmt.Println("Conn.Write错误:", err)
            return
        }
    }
}
