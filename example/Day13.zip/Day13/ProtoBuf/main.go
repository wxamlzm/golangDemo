package main

import (
    "ProtoBuf/pb"
    "fmt"
    "github.com/golang/protobuf/proto"
)

func main() {
    s1 := pb.Student{
        Name: "张飞",
        Age:  20,
        Bday: &pb.Date{
            Year: 2002,
            Mon:  11,
            Day:  11,
        },
        Scores: []int32{80, 90, 100},
        Dayoff: pb.Week_WED,
        Belong: &pb.Student_Class{
            Class: "高二3班",
        },
    }
    show(s1)

    enc, err := proto.Marshal(&s1)
    if err != nil {
        fmt.Println("proto.Marshal错误:", err)
        return
    }
    fmt.Println(enc)

    var s2 pb.Student
    if err := proto.Unmarshal(enc, &s2); err != nil {
        fmt.Println("proto.Unmarshal错误:", err)
        return
    }
    show(s2)
}

func show(s pb.Student) {
    fmt.Printf("姓名：%s\n", s.Name)
    fmt.Printf("年龄：%d\n", s.Age)
    fmt.Printf("生日：%d-%d-%d\n", s.Bday.Year, s.Bday.Mon, s.Bday.Day)
    fmt.Printf("成绩：%d, %d, %d\n", s.Scores[0], s.Scores[1], s.Scores[2])
    fmt.Printf("休息：%s\n", s.Dayoff.String())
    fmt.Printf("隶属：%s\n", s.Belong.(*pb.Student_Class).Class)
}
