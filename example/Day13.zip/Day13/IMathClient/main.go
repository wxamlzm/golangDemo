package main

import (
    "fmt"
    "net/rpc"
    "net/rpc/jsonrpc"
)

type Operands struct {
    A, B int
}

type IArithmetic interface {
    Add(ops Operands, sum *int) error
    Sub(ops Operands, sub *int) error
}

type Arithmetic struct {
    conn *rpc.Client
}

func (arithmetic *Arithmetic) Init(addr string) error {
    conn, err := jsonrpc.Dial("tcp", addr)
    if err == nil {
        arithmetic.conn = conn
    }

    return err
}

func (arithmetic *Arithmetic) Deinit() {
    arithmetic.conn.Close()
}

func (arithmetic *Arithmetic) Add(ops Operands, sum *int) error {
    return arithmetic.conn.Call("arithmetic.Add", ops, sum)
}

func (arithmetic *Arithmetic) Sub(ops Operands, dif *int) error {
    return arithmetic.conn.Call("arithmetic.Sub", ops, dif)
}

func main() {
    var arithmetic Arithmetic

    fmt.Println("请求连接")

    if err := arithmetic.Init("127.0.0.1:9000"); err != nil {
        fmt.Println("Arithmetic.Init错误:", err)
        return
    }

    defer func() {
        fmt.Println("关闭连接")
        arithmetic.Deinit()
    }()

    ops, sum, dif := Operands{123, 456}, 0, 0

    fmt.Println("远程调用")

    if err := arithmetic.Add(ops, &sum); err != nil {
        fmt.Println("Conn.Call错误:", err)
        return
    }

    fmt.Printf("调用返回: %d+%d = %d\n", ops.A, ops.B, sum)

    fmt.Println("远程调用")

    if err := arithmetic.Sub(ops, &dif); err != nil {
        fmt.Println("Conn.Call错误:", err)
        return
    }

    fmt.Printf("调用返回: %d-%d = %d\n", ops.A, ops.B, dif)
}
