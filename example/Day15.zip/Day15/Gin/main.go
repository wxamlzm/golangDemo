package main

import "github.com/gin-gonic/gin"

func main() {
    // 初始化路由
    router := gin.Default()

    // 路由匹配
    router.GET("/", func(contex *gin.Context) {
        contex.Writer.WriteString("Hello World")
    })

    // 运行
    router.Run(":8080")
}
