package main

import (
    "context"

    "github.com/go-micro/plugins/v4/registry/consul"
    pb "helloworld-client/proto"

    "github.com/gin-gonic/gin"
    "go-micro.dev/v4"
    "go-micro.dev/v4/logger"
)

var (
    service = "helloworld"
    version = "latest"
)

func main() {
    // 初始化路由
    router := gin.Default()

    // 路由匹配
    router.GET("/", func(context *gin.Context) {
        context.Writer.WriteString(callHelloworld())
    })

    // 运行
    router.Run(":8080")
}

func callHelloworld() string {
    // Create service
    srv := micro.NewService(micro.Registry(consul.NewRegistry()))
    srv.Init()

    // Create client
    c := pb.NewHelloworldService(service, srv.Client())

    // Call service
    rsp, err := c.Call(context.Background(), &pb.CallRequest{Name: "John"})
    if err != nil {
        logger.Fatal(err)
    }

    return rsp.GetMsg()
}
