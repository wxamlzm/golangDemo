package main

import (
    "fmt"
    "github.com/hashicorp/consul/api"
)

func main() {
    fmt.Println("从Consul中注销服务")

    // 获取Consul默认配置
    config := api.DefaultConfig()

    // 创建Consul客户机
    client, err := api.NewClient(config)
    if err != nil {
        fmt.Println("api.NewClient错误:", err)
        return
    }

    // 从Consul中注销服务
    if err = client.Agent().ServiceDeregister(
        "arithmeticService"); err != nil {
        fmt.Println("Agent.ServiceDeregister错误:", err)
        return
    }

    fmt.Println("服务注销成功")
}
