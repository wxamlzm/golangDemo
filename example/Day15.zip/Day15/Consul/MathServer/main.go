package main

import (
    "context"
    "fmt"
    "gRPC/pb"
    "github.com/hashicorp/consul/api"
    "google.golang.org/grpc"
    "net"
)

type Arithmetic struct {
    pb.UnimplementedArithmeticServer
}

func (arithmetic *Arithmetic) Add(ctx context.Context, ops *pb.Operands) (*pb.Result, error) {
    var res pb.Result
    res.C = ops.A + ops.B
    return &res, nil
}

func (arithmetic *Arithmetic) Sub(ctx context.Context, ops *pb.Operands) (*pb.Result, error) {
    var res pb.Result
    res.C = ops.A - ops.B
    return &res, nil
}

func main() {
    fmt.Println("注册到Consul")

    // 获取Consul默认配置
    config := api.DefaultConfig()
    // 创建Consul客户机
    client, err := api.NewClient(config)
    if err != nil {
        fmt.Println("api.NewClient错误:", err)
        return
    }
    // 构造注册信息
    registration := api.AgentServiceRegistration{
        Name:    "arithmetic",
        ID:      "arithmeticService",
        Tags:    []string{"math"},
        Address: "127.0.0.1",
        Port:    9000,
        Check: &api.AgentServiceCheck{
            CheckID:  "arithmeticHealth",
            TCP:      "127.0.0.1:9000",
            Interval: "5s",
            Timeout:  "1s",
        },
    }
    // 注册到Consul
    if err = client.Agent().ServiceRegister(&registration); err != nil {
        fmt.Println("Agent.ServiceRegister错误:", err)
        return
    }

    server := grpc.NewServer()

    fmt.Println("注册服务")
    pb.RegisterArithmeticServer(server, new(Arithmetic))

    fmt.Println("启动监听")

    listern, err := net.Listen("tcp", "127.0.0.1:9000")
    if err != nil {
        fmt.Println("net.Listen错误:", err)
        return
    }

    defer func() {
        fmt.Println("结束监听")
        listern.Close()
    }()

    fmt.Println("启动服务")
    server.Serve(listern)
}
