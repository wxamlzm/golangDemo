package main

import (
	"GetUser/model"
	"GetUser/handler"
	pb "GetUser/proto"
	"github.com/go-micro/plugins/v4/registry/consul"

	"go-micro.dev/v4"
	"go-micro.dev/v4/logger"
)

var (
	service = "getuser"
	version = "latest"
)

func main() {
	// 初始化数据库
	if err := model.InitDB(); err != nil {
		logger.Fatal(err)
	}

	// Create service
	srv := micro.NewService()
	srv.Init(
		micro.Name(service),
		micro.Version(version),
		micro.Registry(consul.NewRegistry()),
		micro.Address("127.0.0.1:9006"),
	)

	// Register handler
	if err := pb.RegisterGetUserHandler(srv.Server(), new(handler.GetUser)); err != nil {
		logger.Fatal(err)
	}
	// Run service
	if err := srv.Run(); err != nil {
		logger.Fatal(err)
	}
}
