package model

import (
    "crypto/md5"
    "encoding/hex"
    _ "github.com/go-sql-driver/mysql"
    "github.com/jinzhu/gorm"
    "time"
)

// 用户表
type User struct {
    ID            uint     `json:"id"`                            // 用户ID
    Name          string   `json:"name" gorm:"size:32;unique"`    // 用户名
    Password_hash string   `json:"password_hash" gorm:"size:128"` // 密码哈希
    Mobile        string   `json:"mobile" gorm:"size:11;unique"`  // 手机号
    Real_name     string   `json:"real_name" gorm:"size:32"`      // 真实姓名
    Id_card       string   `json:"id_card" gorm:"size:20"`        // 身份证号
    Avatar_url    string   `json:"avatar_url" gorm:"size:256"`    // 头像URL
    Houses        []*House `json:"houses"`                        // 房屋集
    Orders        []*Order `json:"orders"`                        // 订单集
}

// 房屋表
type House struct {
    gorm.Model
    User_id         uint        `json:"user_id"`                                       // 房主用户ID
    Area_id         uint        `json:"area_id"`                                       // 归属地区ID
    Title           string      `json:"title" gorm:"size:64"`                          // 标题
    Address         string      `json:"address" gorm:"size:512"`                       // 地址
    Room_count      int         `json:"room_count" gorm:"default:1"`                   // 房间数
    Acreage         int         `json:"acreage" gorm:"default:0"`                      // 面积
    Price           int         `json:"price"`                                         // 价格
    Unit            string      `json:"unit" gorm:"size:32;default:''"`                // 房间配置
    Capacity        int         `json:"capacity" gorm:"default:1"`                     // 容纳人数
    Beds            string      `json:"beds" gorm:"size:64;default:''"`                // 床铺配置
    Deposit         int         `json:"deposit" gorm:"default:0"`                      // 押金
    Min_days        int         `json:"min_days" gorm:"default:1"`                     // 最少入住天数
    Max_days        int         `json:"max_days" gorm:"default:0"`                     // 最多入住天数
    Order_count     int         `json:"order_count" gorm:"default:0"`                  // 预定订单数
    Index_image_url string      `json:"index_image_url" gorm:"size:256;default:''"`    // 主图片URL
    Facilities      []*Facility `json:"facilities" gorm:"many2many:houses_facilities"` // 设施集
    Images          []*Image    `json:"images"`                                        // 图片集
    Orders          []*Order    `json:"orders"`                                        // 订单集
}

// 城区表
type Area struct {
    ID     uint     `json:"id"`                  // 城区ID
    Name   string   `json:"name" gorm:"size:32"` // 城区名
    Houses []*House `json:"houses"`              // 房屋集
}

// 设施表
type Facility struct {
    ID     uint     `json:"id"`                  // 设施ID
    Name   string   `json:"name" gorm:"size:32"` // 设施名
    Houses []*House `json:"houses"`              // 房屋集
}

// 图片表
type Image struct {
    ID       uint   `json:"id"`                  // 图片ID
    Url      string `json:"url" gorm:"size:256"` // 图片URL
    House_id uint   `json:"house_id"`            // 所属房屋ID
}

// 订单表
type Order struct {
    gorm.Model
    User_id     uint      `json:"user_id"`                             // 下单用户ID
    House_id    uint      `json:"house_id"`                            // 预定房屋ID
    Begin_date  time.Time `json:"begin_date" gorm:"type:datetime"`     // 预定起始日
    End_date    time.Time `json:"end_date" gorm:"type:datetime"`       // 预定终止日
    Days        int       `json:"days"`                                // 预定天数
    House_price int       `json:"house_price"`                         // 房屋价格
    Amount      int       `json:"amount"`                              // 总金额
    Status      string    `json:"status" gorm:"default:'WAIT_ACCEPT'"` // 状态
    Comment     string    `json:"comment" gorm:"size:512"`             // 评论
    Credit      bool      `json:"credit"`                              // 征信良好
}

var db *gorm.DB // 数据库连接池

// 初始化数据库
func InitDB() error {
    var err error

    // 连接数据库
    if db, err = gorm.Open("mysql",
        "root:123456@tcp(127.0.0.1:3306)/ihomedb?"+
            "charset=utf8&parseTime=true&loc=Local"); err == nil {
        // 设置最大连接数喝最大空闲连接数
        db.DB().SetMaxOpenConns(100)
        db.DB().SetMaxIdleConns(10)

        // 创建表
        return db.AutoMigrate(new(User), new(House),
            new(Area), new(Facility), new(Image), new(Order)).Error
    }

    return err
}

// 在MySQL数据库中检查用户是否存在
func CheckUser(mobile, passwd string) (string, error) {
    hasher := md5.New()
    hasher.Write([]byte(passwd))
    passwdHash := hasher.Sum(nil)
    passwdHashBase16 := hex.EncodeToString(passwdHash)

    var user User
    err := db.Select("name").Where("mobile=? and password_hash=?",
        mobile, passwdHashBase16).Find(&user).Error
    return user.Name, err
}
