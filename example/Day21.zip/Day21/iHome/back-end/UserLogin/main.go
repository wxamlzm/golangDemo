package main

import (
    "UserLogin/handler"
    "UserLogin/model"
    pb "UserLogin/proto"
    "github.com/go-micro/plugins/v4/registry/consul"

    "go-micro.dev/v4"
    "go-micro.dev/v4/logger"
)

var (
    service = "userlogin"
    version = "latest"
)

func main() {
    // 初始化数据库
    if err := model.InitDB(); err != nil {
        logger.Fatal(err)
    }

    // Create service
    srv := micro.NewService()
    srv.Init(
        micro.Name(service),
        micro.Version(version),
        micro.Registry(consul.NewRegistry()),
        micro.Address("127.0.0.1:9005"),
    )

    // Register handler
    if err := pb.RegisterUserLoginHandler(srv.Server(), new(handler.UserLogin)); err != nil {
        logger.Fatal(err)
    }
    // Run service
    if err := srv.Run(); err != nil {
        logger.Fatal(err)
    }
}
