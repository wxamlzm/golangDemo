package handler

import (
    "GetSMSCode/model"
    "GetSMSCode/utils"
    "context"
    "fmt"
    "github.com/aliyun/alibaba-cloud-sdk-go/sdk"
    "github.com/aliyun/alibaba-cloud-sdk-go/sdk/auth/credentials"
    "github.com/aliyun/alibaba-cloud-sdk-go/services/dysmsapi"
    "io"
    "math/rand"
    "time"

    "go-micro.dev/v4/logger"

    pb "GetSMSCode/proto"
)

type GetSMSCode struct{}

func (e *GetSMSCode) Call(ctx context.Context, req *pb.CallRequest, rsp *pb.CallResponse) error {
    logger.Infof("Received GetSMSCode.Call request: %v", req)

    // 从Redis数据库中读取图片验证码字符串
    str, err := model.ReadImageCode(req.Uuid)
    if err != nil {
        logger.Error(err)
        rsp.Errno = utils.ERROR_DATABASE
        rsp.Errmsg = utils.StrError(rsp.Errno)
        return nil
    }

    // 校验图片验证码
    if req.Text != str {
        logger.Error("图片验证码校验失败")
        rsp.Errno = utils.ERROR_DATA
        rsp.Errmsg = utils.StrError(rsp.Errno)
        return nil
    }

    // 发送短信验证码
    config := sdk.NewConfig()
    credential := credentials.NewAccessKeyCredential(
        "LTAI5tFHmjLeU9LuKGv1WBDy", "SuYPV5PaRPaE1eBjrjYSTiQMk8Sb0Y")
    client, err := dysmsapi.NewClientWithOptions(
        "cn-hangzhou", config, credential)
    if err != nil {
        logger.Error(err)
        rsp.Errno = utils.ERROR_SMS
        rsp.Errmsg = utils.StrError(rsp.Errno)
        return nil
    }
    request := dysmsapi.CreateSendSmsRequest()
    request.Scheme = "https"
    request.SignName = "阿里云短信测试"
    request.TemplateCode = "SMS_154950909"
    request.PhoneNumbers = req.Mobile
    rand.Seed(time.Now().UnixNano())
    code := fmt.Sprintf("%06d", rand.Int31n(999999))
    request.TemplateParam = "{\"code\": \"" + code + "\"}"
    response, err := client.SendSms(request)
    if err != nil {
        logger.Error(err)
        rsp.Errno = utils.ERROR_SMS
        rsp.Errmsg = utils.StrError(rsp.Errno)
        return nil
    }
    if response.Code != "OK" {
        logger.Error(response.Message)
        rsp.Errno = utils.ERROR_SMS
        rsp.Errmsg = utils.StrError(rsp.Errno)
        return nil
    }

    // 将手机号和短信验证码保存到Redis数据库中
    err = model.SaveSMSCode(req.Mobile, code)
    if err != nil {
        logger.Error(err)
        rsp.Errno = utils.ERROR_DATABASE
        rsp.Errmsg = utils.StrError(rsp.Errno)
        return nil
    }

    rsp.Errno = utils.ERROR_OK
    rsp.Errmsg = utils.StrError(rsp.Errno)
    return nil
}

func (e *GetSMSCode) ClientStream(ctx context.Context, stream pb.GetSMSCode_ClientStreamStream) error {
    var count int64
    for {
        req, err := stream.Recv()
        if err == io.EOF {
            logger.Infof("Got %v pings total", count)
            return stream.SendMsg(&pb.ClientStreamResponse{Count: count})
        }
        if err != nil {
            return err
        }
        logger.Infof("Got ping %v", req.Stroke)
        count++
    }
}

func (e *GetSMSCode) ServerStream(ctx context.Context, req *pb.ServerStreamRequest, stream pb.GetSMSCode_ServerStreamStream) error {
    logger.Infof("Received GetSMSCode.ServerStream request: %v", req)
    for i := 0; i < int(req.Count); i++ {
        logger.Infof("Sending %d", i)
        if err := stream.Send(&pb.ServerStreamResponse{
            Count: int64(i),
        }); err != nil {
            return err
        }
        time.Sleep(time.Millisecond * 250)
    }
    return nil
}

func (e *GetSMSCode) BidiStream(ctx context.Context, stream pb.GetSMSCode_BidiStreamStream) error {
    for {
        req, err := stream.Recv()
        if err == io.EOF {
            return nil
        }
        if err != nil {
            return err
        }
        logger.Infof("Got ping %v", req.Stroke)
        if err := stream.Send(&pb.BidiStreamResponse{Stroke: req.Stroke}); err != nil {
            return err
        }
    }
}
