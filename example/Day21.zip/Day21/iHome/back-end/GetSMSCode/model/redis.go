package model

import "github.com/gomodule/redigo/redis"

// 连接池
var pool = redis.Pool{
    MaxIdle:         20,     // 最大空闲连接数
    MaxActive:       50,     // 最大活动连接数
    MaxConnLifetime: 5 * 60, // 最大连接生命周期
    IdleTimeout:     60,     // 空闲超时
    Dial: func() (redis.Conn, error) { // 连接回调
        // 连接数据库
        return redis.Dial("tcp", "127.0.0.1:6379")
    },
}

// 从Redis数据库中读取图片验证码字符串
func ReadImageCode(uuid string) (string, error) {
    // 从连接池中获取连接
    conn := pool.Get()

    // 关闭数据库连接
    defer conn.Close()

    // 操作数据库同时类型具体
    return redis.String(conn.Do("get", uuid))
}

// 将手机号和短信验证码保存到Redis数据库中
func SaveSMSCode(mobile, code string) error {
    // 从连接池中获取连接
    conn := pool.Get()

    // 关闭数据库连接
    defer conn.Close()

    // 操作数据库
    _, err := conn.Do("setex", mobile, 60*3, code)
    return err
}
