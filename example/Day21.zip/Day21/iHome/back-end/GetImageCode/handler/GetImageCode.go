package handler

import (
    "GetImageCode/model"
    "context"
    "encoding/json"
    "fmt"
    "image/color"
    "io"
    "time"

    "go-micro.dev/v4/logger"

    pb "GetImageCode/proto"

    "github.com/afocus/captcha"
)

type GetImageCode struct{}

func (e *GetImageCode) Call(ctx context.Context, req *pb.CallRequest, rsp *pb.CallResponse) error {
    logger.Infof("Received GetImageCode.Call request: %v", req)

    // 生成图片验证码
    cap := captcha.New()
    cap.SetFont("./resources/comic.ttf")
    cap.SetSize(128, 64)
    cap.SetDisturbance(captcha.MEDIUM)
    cap.SetFrontColor(color.RGBA{255, 255, 255, 255})
    cap.SetBkgColor(color.RGBA{49, 174, 54, 255})
    img, str := cap.Create(4, captcha.NUM)

    jsonImg, err := json.Marshal(img)
    if err != nil {
        logger.Error(err)
        return err
    }
    rsp.Img = jsonImg

    fmt.Println(str)

    // 将图片验证码的UUID和验证码字符串保存到Redis数据库中
    if err := model.SaveImageCode(req.Uuid, str); err != nil {
        logger.Error(err)
        return err
    }

    return nil
}

func (e *GetImageCode) ClientStream(ctx context.Context, stream pb.GetImageCode_ClientStreamStream) error {
    var count int64
    for {
        req, err := stream.Recv()
        if err == io.EOF {
            logger.Infof("Got %v pings total", count)
            return stream.SendMsg(&pb.ClientStreamResponse{Count: count})
        }
        if err != nil {
            return err
        }
        logger.Infof("Got ping %v", req.Stroke)
        count++
    }
}

func (e *GetImageCode) ServerStream(ctx context.Context, req *pb.ServerStreamRequest, stream pb.GetImageCode_ServerStreamStream) error {
    logger.Infof("Received GetImageCode.ServerStream request: %v", req)
    for i := 0; i < int(req.Count); i++ {
        logger.Infof("Sending %d", i)
        if err := stream.Send(&pb.ServerStreamResponse{
            Count: int64(i),
        }); err != nil {
            return err
        }
        time.Sleep(time.Millisecond * 250)
    }
    return nil
}

func (e *GetImageCode) BidiStream(ctx context.Context, stream pb.GetImageCode_BidiStreamStream) error {
    for {
        req, err := stream.Recv()
        if err == io.EOF {
            return nil
        }
        if err != nil {
            return err
        }
        logger.Infof("Got ping %v", req.Stroke)
        if err := stream.Send(&pb.BidiStreamResponse{Stroke: req.Stroke}); err != nil {
            return err
        }
    }
}
