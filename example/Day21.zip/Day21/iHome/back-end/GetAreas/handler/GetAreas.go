package handler

import (
	"GetAreas/model"
	"GetAreas/utils"
	"context"
	"io"
	"time"

	"go-micro.dev/v4/logger"

	pb "GetAreas/proto"
)

type GetAreas struct{}

func (e *GetAreas) Call(ctx context.Context, req *pb.CallRequest, rsp *pb.CallResponse) error {
	logger.Infof("Received GetAreas.Call request: %v", req)

	// 从Redis数据库中加载城区列表
	areas, err := model.LoadAreas()
	if err != nil {
		// 从MySQL数据库中读取城区列表
		areas, err = model.ReadAreas()
		if err != nil {
			logger.Error(err)
			rsp.Errno = utils.ERROR_DATABASE
			rsp.Errmsg = utils.StrError(rsp.Errno)
			return nil
		}

		// 将城区列表保存到Redis数据库中
		model.SaveAreas(areas)
	}

	for _, area := range areas {
		rsp.Data = append(rsp.Data, &pb.Area{
			Aid:   uint64(area.ID),
			Aname: area.Name,
		})
	}

	rsp.Errno = utils.ERROR_OK
	rsp.Errmsg = utils.StrError(rsp.Errno)
	return nil
}

func (e *GetAreas) ClientStream(ctx context.Context, stream pb.GetAreas_ClientStreamStream) error {
	var count int64
	for {
		req, err := stream.Recv()
		if err == io.EOF {
			logger.Infof("Got %v pings total", count)
			return stream.SendMsg(&pb.ClientStreamResponse{Count: count})
		}
		if err != nil {
			return err
		}
		logger.Infof("Got ping %v", req.Stroke)
		count++
	}
}

func (e *GetAreas) ServerStream(ctx context.Context, req *pb.ServerStreamRequest, stream pb.GetAreas_ServerStreamStream) error {
	logger.Infof("Received GetAreas.ServerStream request: %v", req)
	for i := 0; i < int(req.Count); i++ {
		logger.Infof("Sending %d", i)
		if err := stream.Send(&pb.ServerStreamResponse{
			Count: int64(i),
		}); err != nil {
			return err
		}
		time.Sleep(time.Millisecond * 250)
	}
	return nil
}

func (e *GetAreas) BidiStream(ctx context.Context, stream pb.GetAreas_BidiStreamStream) error {
	for {
		req, err := stream.Recv()
		if err == io.EOF {
			return nil
		}
		if err != nil {
			return err
		}
		logger.Infof("Got ping %v", req.Stroke)
		if err := stream.Send(&pb.BidiStreamResponse{Stroke: req.Stroke}); err != nil {
			return err
		}
	}
}
