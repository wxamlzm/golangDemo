package model

import (
    "github.com/gin-contrib/sessions"
    "github.com/gin-contrib/sessions/redis"
    "github.com/gin-gonic/gin"
)

// 初始化Session
func InitSession(router *gin.Engine) error {
    // 创建Session容器
    store, err := redis.NewStore(
        10, "tcp", "localhost:6379", "", []byte("ihome"))
    if err == nil {
        // 为容器中的Session设置Cookie的键
        router.Use(sessions.Sessions("ihome", store))

        // 为容器中的Session设置选项
        store.Options(sessions.Options{
            Path:     "",
            Domain:   "",
            MaxAge:   7 * 24 * 3600,
            Secure:   true,
            HttpOnly: true,
        })
    }

    return err
}

// 将用户名保存到Session中
func SaveUsername(ctx *gin.Context, username string) error {
    // 获取Session
    session := sessions.Default(ctx)
    // 设置Session中指定键的值
    session.Set("username", username)
    // 保存Session
    return session.Save()
}

// 从Session中读取用户名
func ReadUsername(ctx *gin.Context) string {
    username := ""

    // 获取Session
    session := sessions.Default(ctx)
    // 获取Session中指定键的值
    if iusername := session.Get("username"); iusername != nil {
        username = iusername.(string)
    }

    return username
}

// 从Session中删除用户名
func DeleteUsername(ctx *gin.Context) error {
    // 获取Session
    session := sessions.Default(ctx)
    // 删除Session中指定的键值对
    session.Delete("username")
    // 保存Session
    return session.Save()
}
