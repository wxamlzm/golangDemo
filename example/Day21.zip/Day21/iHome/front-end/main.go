package main

import (
    "fmt"
    "github.com/gin-gonic/gin"
    "iHome/front-end/controller"
    "iHome/front-end/model"
)

func main() {
    /*
       // 初始化数据库
       if err := model.InitDB(); err != nil {
           fmt.Println("model.InitDB错误:", err)
           return
       }
    */
    // 初始化路由
    router := gin.Default()

    // 初始化Session
    if err := model.InitSession(router); err != nil {
        fmt.Println("model.InitSession错误:", err)
        return
    }

    // 路由匹配
    router.Static("/home", "./view")
    apiv10 := router.Group("/api/v1.0")
    apiv10.GET("/session", controller.GetSession)
    apiv10.GET("/imagecode/:uuid", controller.GetImageCode)
    apiv10.GET("/smscode/:mobile", controller.GetSMSCode)
    apiv10.POST("/users", controller.UserRegister)
    apiv10.GET("/areas", controller.GetAreas)
    apiv10.POST("/sessions", controller.UserLogin)
    apiv10.DELETE("/session", controller.UserLogout)
    apiv10.GET("/user", controller.GetUser)

    // 运行
    router.Run(":8080")
}
