package main

import "github.com/gin-gonic/gin"

func main() {
    // 初始化路由
    router := gin.Default()

    // 路由匹配
    router.GET("/", func(contex *gin.Context) {
        // 获取Cookie
        username, err := contex.Cookie("username")
        if err != nil {
            contex.Writer.WriteString(err.Error())
            return
        }
        contex.Writer.WriteString(username)
    })

    // 运行
    router.Run(":8080")
}
