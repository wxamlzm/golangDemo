package main

import (
    "fmt"
    _ "github.com/go-sql-driver/mysql"
    "github.com/jinzhu/gorm"
)

var db *gorm.DB // 数据库连接池

// 描述表的结构体
type Student struct {
    /*
       ID int // 默认主键，主键索引，查询速度快，自动增长
    */
    gorm.Model        // 基类，含ID、DeletedAt等字段
    Name       string `gorm:"size:50;default:'匿名'"`
    Age        int    `gorm:"not null"`
}

func main() {
    var err error

    // 连接数据库
    db, err = gorm.Open("mysql",
        "root:123456@tcp(127.0.0.1:3306)/testdb?charset=utf8&parseTime=True&loc=Local")
    if err != nil {
        fmt.Println("MySQL错误:", err)
        return
    }

    // 设置最大连接数和最大空闲连接数
    db.DB().SetMaxOpenConns(100)
    db.DB().SetMaxIdleConns(10)

    // 创建表
    if err = db.AutoMigrate(new(Student)).Error; err != nil {
        fmt.Println("MySQL错误:", err)
        return
    }

    // 插入数据
    if !insert() {
        return
    }

    // 查询数据
    if !query() {
        return
    }

    // 更新数据
    if !update() {
        return
    }
    if !query() {
        return
    }

    // 删除数据
    if !delete() {
        return
    }
    if !query() {
        return
    }

    // 关闭数据库连接
    defer db.Close()
}

// 插入数据
func insert() bool {
    if err := db.Create(&Student{Name: "张飞", Age: 25}).Error; err != nil {
        fmt.Println("MySQL错误:", err)
        return false
    }

    if err := db.Create(&Student{Name: "关羽", Age: 30}).Error; err != nil {
        fmt.Println("MySQL错误:", err)
        return false
    }

    if err := db.Create(&Student{Name: "赵云", Age: 20}).Error; err != nil {
        fmt.Println("MySQL错误:", err)
        return false
    }

    return true
}

// 查询数据
func query() bool {
    var students []Student

    if err := db.Select("id,name,age").Where("(name='关羽' or age<?)", 25).Unscoped().Find(&students).Error; err != nil {
        fmt.Println("MySQL错误:", err)
        return false
    }

    for _, student := range students {
        fmt.Println(student.ID, student.Name, student.Age)
    }

    return true
}

// 更新数据
func update() bool {
    if err := db.Model(new(Student)).Where("name='关羽'").
        Update("age", 35).Error; err != nil {
        fmt.Println("MySQL错误:", err)
        return false
    }

    if err := db.Model(new(Student)).Where("name='赵云'").
        Updates(map[string]interface{}{"name": "子龙", "age": 15}).Error; err != nil {
        fmt.Println("MySQL错误:", err)
        return false
    }

    student := Student{Name: "张飞", Age: 10}
    student.ID = 1
    if err := db.Save(&student).Error; err != nil {
        fmt.Println("MySQL错误:", err)
        return false
    }

    return true
}

// 删除数据
func delete() bool {
    // 软删除
    if err := db.Where("name='张飞'").Delete(new(Student)).Error; err != nil {
        fmt.Println("MySQL错误:", err)
        return false
    }

    // 硬删除
    if err := db.Where("name='张飞'").Unscoped().Delete(new(Student)).Error; err != nil {
        fmt.Println("MySQL错误:", err)
        return false
    }

    return true
}
