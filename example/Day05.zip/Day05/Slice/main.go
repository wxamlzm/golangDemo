package main

import "fmt"

func main() {
    var a []int
    fmt.Println(a)
    var b []int = []int{1, 2, 3, 4, 5}
    fmt.Println(b)
    var c = []int{1, 2, 3, 4, 5}
    fmt.Println(c)
    d := []int{1, 2, 3, 4, 5}
    fmt.Println(d)

    e := append(d, 6)
    fmt.Println(d, e)

    f := []int{}
    for value := 1; value < 10; value++ {
        f = append(f, value)
        fmt.Println(f, len(f), cap(f))
    }

    g := [10]rune{'一', '二', '三', '四', '五', '六', '七', '八', '九', '十'}
    for _, r := range g {
        fmt.Printf("%c", r)
    }
    fmt.Println()
    h := g[2:8]
    for _, r := range h {
        fmt.Printf("%c", r)
    }
    fmt.Println()
    i := h[2:4]
    for _, r := range i {
        fmt.Printf("%c", r)
    }
    fmt.Println()
    i[0], i[1] = '伍', '陆'
    for _, r := range i {
        fmt.Printf("%c", r)
    }
    fmt.Println()
    for _, r := range h {
        fmt.Printf("%c", r)
    }
    fmt.Println()
    for _, r := range g {
        fmt.Printf("%c", r)
    }
    fmt.Println()

    i = g[:3]
    for _, r := range i {
        fmt.Printf("%c", r)
    }
    fmt.Println()

    i = g[7:]
    for _, r := range i {
        fmt.Printf("%c", r)
    }
    fmt.Println()

    i = g[:]
    //j := g
    for _, r := range /*j*/ i {
        fmt.Printf("%c", r)
    }
    fmt.Println()
    /*j*/ i[4], /*j*/ i[5] = '5', '6'
    for _, r := range /*j*/ i {
        fmt.Printf("%c", r)
    }
    fmt.Println()
    for _, r := range g {
        fmt.Printf("%c", r)
    }
    fmt.Println()

    k := "ABCDEFGHIJ"
    fmt.Println(k)
    l := k[2:8]
    fmt.Println(l)
    m := l[2:4]
    fmt.Println(m)

    n := make([]int, 5)
    fmt.Println(n, len(n), cap(n))
    o := make([]int, 5, 10)
    fmt.Println(o, len(o), cap(o))

    p := []int{1, 2}
    q := []int{3, 4}
    r := []int{5, 6}
    fmt.Println(p, q, r)
    q = p
    copy(r, p)
    fmt.Println(p, q, r)
    p[0], p[1] = 7, 8
    fmt.Println(p, q, r)
}
