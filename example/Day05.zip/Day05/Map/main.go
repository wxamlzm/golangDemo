package main

import "fmt"

func main() {
    var a map[string]int
    a = make(map[string]int, 5)
    a["张飞"] = 80
    a["赵云"] = 70
    a["关羽"] = 90
    fmt.Println(a)
    var b map[string]int = make(map[string]int, 5)
    b["张飞"] = 80
    b["赵云"] = 70
    b["关羽"] = 90
    fmt.Println(b)
    var c = make(map[string]int, 5)
    c["张飞"] = 80
    c["赵云"] = 70
    c["关羽"] = 90
    fmt.Println(c)
    d := make(map[string]int, 5)
    d["张飞"] = 80
    d["赵云"] = 70
    d["关羽"] = 90
    fmt.Println(d)

    fmt.Println(d["黄忠"])
    e, ok := d["黄忠"]
    fmt.Println(e, ok)
    f, ok := d["张飞"]
    fmt.Println(f, ok)

    for key, value := range d {
        fmt.Println(key, value)
    }
    delete(d, "赵云")
    fmt.Println(d)
    delete(d, "黄忠")
    fmt.Println(d)
    g := d
    fmt.Println(d, g)
    g["张飞"]++
    d["马超"] = 60
    fmt.Println(d, g)
}
